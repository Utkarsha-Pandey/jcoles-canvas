import { Editor } from "@/features/editor/components/editor";

const EditorProjectIdPage = () => {
    return (
        <>
            <Editor/>
        </>
    );
};

export default EditorProjectIdPage;

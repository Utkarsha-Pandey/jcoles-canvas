# jcoles-canvas
A web-based design tool that allows students, faculty, and clubs to easily create stunning visuals for campus-themed events, organizations, and personal projects.
